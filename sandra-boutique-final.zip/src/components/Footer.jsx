import React from "react";

export default function Footer() {
  return (
    <footer className="bg-gray-100 p-6 text-sm mt-10">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div>
          <h4 className="font-semibold">Informação</h4>
          <ul>
            <li>Sobre nós</li>
            <li>Privacidade</li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold">Ajuda</h4>
          <ul>
            <li>Como comprar</li>
            <li>Metodos de pagamento</li>
            <li>Perguntas frequentes</li>
            <li>Contatos</li>
          </ul>
        </div>
      </div>
      <p className="text-center mt-4 text-xs">© Copyright 2025, Exemplo</p>
    </footer>
  );
}