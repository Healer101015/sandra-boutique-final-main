import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="bg-white shadow p-4 flex justify-between items-center">
      <div className="text-xl font-bold text-yellow-600">Pele brasileira</div>
      <ul className="flex gap-4 text-sm">
        <li>Inicio</li>
        <li>Estetica</li>
        <li>Produtos</li>
        <li>Outros</li>
      </ul>
      <div className="flex gap-2 items-center">
        <input
          type="text"
          placeholder="Buscar..."
          className="border p-1 rounded text-sm"
        />
        <Link to="/login" className="text-sm bg-black text-white px-2 py-1 rounded">
          Login
        </Link>

        <Link to="/Register" className="text-sm bg-black text-white px-2 py-1 rounded">
          Registro
        </Link>

      </div>
    </nav>
  );
}
