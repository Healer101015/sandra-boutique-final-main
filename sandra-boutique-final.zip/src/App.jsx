// src/App.jsx
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Home from "./pages/Home";
import Cart from "./pages/Cart";
import ClientInfo from "./pages/ClientInfo";
import Register from "./pages/Register";
import Login from "./pages/Login"; // se ainda não criou, posso gerar o arquivo
import PrivateRoute from "./components/PrivateRoute"; // também posso gerar

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={
            <PrivateRoute><ClientInfo /></PrivateRoute>
          } />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
