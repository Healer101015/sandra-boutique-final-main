import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow p-4">
        <section className="text-center bg-[#f4f4f4] py-10">
          <h1 className="text-2xl font-bold mb-2">DESCUBRA A MODA MAIS ATUAL</h1>
          <p>encontre seu visual estetico</p>
          <button className="mt-4 bg-black text-white px-4 py-2">COMPRA AGORA</button>
        </section>
      </main>
      <Footer />
    </div>
  );
}