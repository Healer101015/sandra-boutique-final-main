import { useState } from "react";
import axios from "axios";

export default function Register() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const register = async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://localhost:4000/api/register", { email, password });
            alert("Usuário criado!");
        } catch (err) {
            alert("Erro ao registrar");
        }
    };

    return (
        <form onSubmit={register} className="max-w-md mx-auto mt-10 p-4 border rounded">
            <h2 className="text-xl mb-4">Registro</h2>
            <input
                type="email"
                placeholder="Email"
                className="border p-2 w-full mb-2"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
            />
            <input
                type="password"
                placeholder="Senha"
                className="border p-2 w-full mb-2"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
            />
            <button className="bg-black text-white px-4 py-2">Registrar</button>
        </form>
    );
}
