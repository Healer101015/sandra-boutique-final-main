import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function Cart() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow p-6">
        <h2 className="text-xl font-semibold mb-4">TU CARRITO (3 Artículos)</h2>
        <div className="border p-4">Tabla de produtos simulada...</div>
      </main>
      <Footer />
    </div>
  );
}