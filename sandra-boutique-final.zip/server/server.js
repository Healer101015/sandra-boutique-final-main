// server/server.js
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("./models/User");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/pelebrasileira");

app.post("/api/register", async (req, res) => {
    const { email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    try {
        const user = await User.create({ email, password: hashedPassword });
        res.status(201).json({ message: "Usuário criado", user });
    } catch (error) {
        res.status(400).json({ error: "Erro ao registrar usuário" });
    }
});

app.post("/api/login", async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ error: "Credenciais inválidas" });
    }
    const token = jwt.sign({ id: user._id }, "secret", { expiresIn: "1d" });
    res.json({ token });
});

app.get("/api/me", async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.sendStatus(401);
    try {
        const token = authHeader.split(" ")[1];
        const decoded = jwt.verify(token, "secret");
        const user = await User.findById(decoded.id);
        res.json({ user });
    } catch (err) {
        res.sendStatus(403);
    }
});

app.listen(4000, () => {
    console.log("Servidor rodando na porta 4000");
});

console.log(mongoose.connection.readyState === 1 ? "Conectado ao MongoDB" : "Erro ao conectar ao MongoDB");
console.log(mongoose.connection.readyState);