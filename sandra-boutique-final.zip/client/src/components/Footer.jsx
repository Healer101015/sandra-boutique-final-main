// Footer component - Em construção
export default function Footer() {
  return <div>Footer</div>;
}