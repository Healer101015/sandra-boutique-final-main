// Página de informação do cliente - Em construção
export default function ClientInfo() {
  return <div>Client Info Page</div>;
}