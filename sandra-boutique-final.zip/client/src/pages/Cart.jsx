// Página do carrinho - Em construção
export default function Cart() {
  return <div>Cart Page</div>;
}